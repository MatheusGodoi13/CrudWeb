package com.example.trabalho

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
