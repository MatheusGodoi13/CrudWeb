// lib/services/medicamento_service.dart
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../model/medicamentos.dart';

class MedicamentoService {
  static const String _baseUrl = 'http://10.0.2.2:8080/api/medicamentos'; // Para emulador Android

  // Busca medicamentos por termo
  static Future<List<Medicamento>> buscarMedicamentos(String termo) async {
    final response = await http.get(
      Uri.parse('$_baseUrl/buscar?termo=$termo'),
    );

    if (response.statusCode == 200) {
      final List<dynamic> jsonList = json.decode(response.body);
      return jsonList.map((json) => Medicamento.fromJson(json)).toList();
    } else {
      throw Exception('Falha ao carregar medicamentos');
    }
  }

  // Busca medicamento por ID
  static Future<Medicamento> getMedicamento(int id) async {
    final response = await http.get(
      Uri.parse('$_baseUrl/$id'),
    );

    if (response.statusCode == 200) {
      return Medicamento.fromJson(json.decode(response.body));
    } else {
      throw Exception('Falha ao carregar medicamento');
    }
  }
}