// lib/pages/busca_medicamentos_page.dart
import 'package:flutter/material.dart';
import '../services/medicamento_service.dart';
import '../model/medicamentos.dart';

class BuscaMedicamentosPage extends StatefulWidget {
  const BuscaMedicamentosPage({super.key});

  @override
  _BuscaMedicamentosPageState createState() => _BuscaMedicamentosPageState();
}

class _BuscaMedicamentosPageState extends State<BuscaMedicamentosPage> {
  final TextEditingController _controller = TextEditingController();
  List<Medicamento> _medicamentos = [];
  bool _carregando = false;

  Future<void> _buscarMedicamentos() async {
    setState(() => _carregando = true);
    
    try {
      final medicamentos = await MedicamentoService.buscarMedicamentos(_controller.text);
      setState(() => _medicamentos = medicamentos);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Erro: ${e.toString()}')),
      );
    } finally {
      setState(() => _carregando = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Consulta de Medicamentos')),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _controller,
              decoration: InputDecoration(
                labelText: 'Digite o nome ou princípio ativo',
                suffixIcon: IconButton(
                  icon: Icon(Icons.search),
                  onPressed: _buscarMedicamentos,
                ),
              ),
              onSubmitted: (_) => _buscarMedicamentos(),
            ),
            SizedBox(height: 20),
            _carregando
                ? CircularProgressIndicator()
                : Expanded(
                    child: ListView.builder(
                      itemCount: _medicamentos.length,
                      itemBuilder: (context, index) {
                        final med = _medicamentos[index];
                        return ListTile(
                          title: Text(med.nomeComercial),
                          subtitle: Text(med.principioAtivo),
                          trailing: med.receitaObrigatoria
                              ? Icon(Icons.warning, color: Colors.orange)
                              : null,
                          onTap: () {
                            // Navegar para detalhes
                          },
                        );
                      },
                    ),
                  ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
}