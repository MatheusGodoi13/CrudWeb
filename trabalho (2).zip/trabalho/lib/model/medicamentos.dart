class Medicamento {
  final int? id;
  final String nomeComercial;
  final String principioAtivo;
  final String indicacoes;
  final String contraIndicacoes;
  final String posologia;
  final String efeitosColaterais;
  final String fabricante;
  final bool receitaObrigatoria;

  Medicamento({
    this.id,
    required this.nomeComercial,
    required this.principioAtivo,
    required this.indicacoes,
    required this.contraIndicacoes,
    required this.posologia,
    required this.efeitosColaterais,
    required this.fabricante,
    required this.receitaObrigatoria,
  });


  factory Medicamento.fromJson(Map<String, dynamic> json) {
    return Medicamento(
      id: json['id'],
      nomeComercial: json['nomeComercial'],
      principioAtivo: json['principioAtivo'],
      indicacoes: json['indicacoes'],
      contraIndicacoes: json['contraIndicacoes'],
      posologia: json['posologia'],
      efeitosColaterais: json['efeitosColaterais'],
      fabricante: json['fabricante'],
      receitaObrigatoria: json['receitaObrigatoria'],
    );
  }

  // Método para converter para JSON (se necessário enviar para API)
  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'nomeComercial': nomeComercial,
      'principioAtivo': principioAtivo,
      'indicacoes': indicacoes,
      'contraIndicacoes': contraIndicacoes,
      'posologia': posologia,
      'efeitosColaterais': efeitosColaterais,
      'fabricante': fabricante,
      'receitaObrigatoria': receitaObrigatoria,
    };
  }
}